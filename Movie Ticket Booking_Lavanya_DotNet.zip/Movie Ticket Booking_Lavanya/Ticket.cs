using System;
using System.Collections.Generic;
namespace Movie_Ticket_Bookings{
 public class Ticket{

                                    
     private string name="",password="";
       public Ticket(){}

      //Constructor to assign user values
       public Ticket(string name,string password)
       {
          this.name=name;
          this.password=password;
       }
      
      //getting name and password 
       public string getName(){
           return name;
       }
       public string getPassword(){
           return password;
       }

    //seat allocation           
    int[] Seats=new int[600];


//view seats
 public void viewSeats(){

     Console.WriteLine("\n============================= SCREEN =================================\n");
        for(int j=0;j<Seats.Length;j++){
            if(j%30==0){
                Console.WriteLine();
                Console.Write(Seats[j]+" ");
            }
            else if(j%10==0){
                Console.Write("      ");
                Console.Write(Seats[j]+" ");
            }

            else{ Console.Write(Seats[j]+" ");}
        }
        Console.WriteLine();
        Console.WriteLine("-------------------------------------------------");
        getOption();
    }

//booking movie tickets 
 public void bookTicket(){
     Console.WriteLine("-------------------------------------------------");
            Console.WriteLine("\n\nEnter a Seat Number : ");
            Console.WriteLine("-------------------------------------------------");
            string temp =Console.ReadLine();
            int sNum=int.Parse(temp);
            if(Seats[sNum-1]==0){
                Seats[sNum-1]=1;
                Console.WriteLine("\nYour Seat Booked Successfully");
                Console.WriteLine("-------------------------------------------------");  
                
            }
            else{
                Console.WriteLine("-------------------------------------------------");
                Console.WriteLine("\nSeat Already Booked... Try Another");
            }
        Console.WriteLine("-------------------------------------------------");    
         viewSeats();
         getOption();
        }

//cencelling movie tickets
 public void cancelTicket(){
     Console.WriteLine("-------------------------------------------------");
    Console.WriteLine("\nEnter your seat number to cancel");
    Console.WriteLine("-------------------------------------------------");
    string temp=Console.ReadLine();
    int sNum=int.Parse(temp);
    if(Seats[sNum-1]==1){
        Seats[sNum-1]=0;
        Console.WriteLine("\nYour Ticket Cancelled Successfully");
        Console.WriteLine("-------------------------------------------------");
    }
    else{
        Console.WriteLine("\nTicket is not Booked");
    }
    Console.WriteLine("-------------------------------------------------");
    viewSeats();
    getOption();
 }

//showing details to user
  public void getOption(){
      Console.WriteLine("-------------------------------------------------");
     Console.WriteLine("\n1.View Seats \n2.Book Ticket \n3.Cancel a Ticket \n");
     Console.WriteLine("-------------------------------------------------");
     string options= Console.ReadLine();           //user input for choise
     switch(options){
         case "1":viewSeats();
             break;
         case "2":
             bookTicket();
             break;
         case "3":
            cancelTicket();
             break;
         default:
              Console.WriteLine("Input Invalid");
              getOption();
              break;
       }
    }
  
   }

}

