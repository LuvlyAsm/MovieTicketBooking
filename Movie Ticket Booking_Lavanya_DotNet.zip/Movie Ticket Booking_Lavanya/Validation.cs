using System;
using System.Collections.Generic;
namespace Movie_Ticket_Bookings{
 public class Validation
    {
        public void validate(){
       //userinputs

        //Existing User Details
        List<Ticket> userDetails=new List<Ticket>();

        Ticket person1=new Ticket("ASM","Password@123");

        Ticket person2=new Ticket("Lavanya","Password@1234");

        Ticket person3=new Ticket("Karthik","Password@12345");

        Ticket person4=new Ticket("Dhilip","Password@123456");

        Ticket person5=new Ticket("Saranya","Password@123456");

        //Adding user inputs to List

        userDetails.Add(person1);

        userDetails.Add(person2);

        userDetails.Add(person3);

        userDetails.Add(person4);

        userDetails.Add(person5);

         Console.WriteLine("-------------------------------------------------");
        Console.WriteLine("-------------------------------------------------Welcome to our ABC Ticket...\n-------------------------------------------------\n1.LogIn\n2.Signup\n\nEnter 1 or 2 to continue....");
        Console.WriteLine("-------------------------------------------------");

        string choice = Console.ReadLine();

        //login
        if(choice.Equals("1")){

        try
        {
            //Taking User Inputs
            Console.WriteLine("-------------------------------------------------");
            Console.WriteLine("Enter Username");

            string name=Console.ReadLine();

            Console.WriteLine("Enter Password");

            string pass=Console.ReadLine();
            Console.WriteLine("-------------------------------------------------"); 

             //User Detail validation
             int count=0; 
            foreach(Ticket ticket in userDetails){
              
               if(name.Equals(ticket.getName())&&pass.Equals(ticket.getPassword())){
                Console.WriteLine("-------------------------------------------------");
                Console.WriteLine("Logged In Successfully");
                Console.WriteLine("-------------------------------------------------");

                   count=1;

                   ticket.getOption();}
               }
               //if user not present in list,this will execute
               if(count==0){
                   Console.WriteLine("-------------------------------------------------");
                       Console.WriteLine("\nPlease enter Valid Details\n");
                       Console.WriteLine("-------------------------------------------------");
                       validate();
                   }

        }
        //for invalid details
        catch (Exception exception)
        {
            Console.WriteLine("-------------------------------------------------");
            Console.WriteLine("Enter Valid Details");
            Console.WriteLine("-------------------------------------------------");
            validate();

        }

    }    

        //Signup
        else if(choice.Equals("2")){
            //Taking user inputs
        Console.WriteLine("-------------------------------------------------");
        Console.WriteLine("Enter Username");

             string name=Console.ReadLine();

        Console.WriteLine("Enter Password");

            string pass=Console.ReadLine();
           
           Console.WriteLine("-------------------------------------------------");

       //new user details adding
            Ticket newUser=new Ticket(name,pass);

            userDetails.Add(newUser);

        Console.WriteLine("-------------------------------------------------");
            Console.WriteLine("Registered Successfully");
        Console.WriteLine("-------------------------------------------------");
            newUser.getOption();

        }
        
        else{
        Console.WriteLine("-------------------------------------------------");
        Console.WriteLine("Input Invalid");
        Console.WriteLine("-------------------------------------------------");
        validate();

        }

        }   


 }

}