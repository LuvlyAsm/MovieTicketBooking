﻿/*​

Title: Movie Ticket Booking Application​

Author: Lavanya B​

Created at:07-June-2022​

Updated at: 09-June-2022​

Reviewed by:Sabapathi Shanmugam

Reviewed at: 08-June-2022​

*/

using System;

namespace Movie_Ticket_Bookings
{
   public class Program
    {
        static void Main(string[] args)
        {
          Validation validation=new Validation();
          validation.validate();
        }
    }
}